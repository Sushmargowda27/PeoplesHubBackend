package com.example.People.s.Hub.Service;

public interface AdminService {
	public String login(String email, String password);
	public Object forgot(String email);
}
